const canvas = document.getElementById("area");
const ctx = canvas.getContext("2d");

//cargar la imagen
const sprite = new Image();
sprite.src = "imgs/gato.png";


function animar(){
    //206 de ancho, 206 alto
    ctx.drawImage(
        sprite, 10,10, 300, 200
    );
    ctx.drawImage(
        sprite, 300,320
    );
}



//esperar hasta cargar la imagen 
sprite.onload = () => {
    requestAnimationFrame(animar);
}
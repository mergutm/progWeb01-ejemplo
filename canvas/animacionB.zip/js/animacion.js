const canvas = document.getElementById("area");
const ctx = canvas.getContext("2d");

//cargar la imagen
const sprite = new Image();
sprite.src = "imgs/gato.png";

let posiciones = [];
const anchox = 206;
const altoy = 206;

for (let fila=0; fila<2; fila++){
    for(let col=0; col<3; col++ ){
        posiciones.push( [col*anchox, fila*altoy ] );
    }

}
console.log(posiciones);
let indice = 0;
let cuenta = 0;


function animar(){
    //206 de ancho, 206 alto
    //https://developer.mozilla.org/es/docs/Web/API/CanvasRenderingContext2D/drawImage
    //ctx.drawImage( sprite, 10,10, 300, 200    );
    //ctx.drawImage(sprite, 300,320 );

    ctx.drawImage(sprite, 
        posiciones[indice][0],  posiciones[indice][1], anchox, altoy, //dentro de la imagen
        100,100, anchox*2, altoy*2,
    );

    if (cuenta%5 == 0){
        indice = (indice +1) % posiciones.length;  // 0,1,2,3,4,5,0,1,2,3,4,5,0,,,
    }
    cuenta++;

    requestAnimationFrame(animar);
}



//esperar hasta cargar la imagen 
sprite.onload = () => {
    animar();
}